package com.codinginflow.mvvmtodo.util

val <T> T.exhaustive: T
    get() = this